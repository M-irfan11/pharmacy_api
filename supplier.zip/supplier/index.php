<?php
include '../connection.php';
$result=$cc->common_select('supplier');
echo json_encode($result);